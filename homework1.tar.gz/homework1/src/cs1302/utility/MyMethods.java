package cs1302.utility;
public class MyMethods {
    public static int maxCheck(int a, int b) {
	if (a > b ) {
	    return a;
	} else {
	    return b;
	}
    }
}
